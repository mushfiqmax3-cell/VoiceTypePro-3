package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

/**
 * High-reliability Audio Recorder that captures raw 16kHz 16-bit mono PCM audio via [AudioRecord],
 * applies smart automatic gain normalization (so quiet, faint, or emulator speech is boosted to clear speech levels),
 * and writes a standard RIFF `.wav` ("audio/wav") file to [Context.getCacheDir].
 *
 * Designed to solve "No speech detected" issues across Android devices and emulators:
 * 1. Multi-source fallback: VOICE_RECOGNITION -> MIC -> DEFAULT -> VOICE_COMMUNICATION.
 * 2. Ultra-low minimum audio threshold (>= 50ms) so short speech ("হ্যাঁ", "Hello", "OK") is preserved.
 * 3. Continuous recording without aggressive silence cutoffs until the user taps stop.
 * 4. Resilient read loop that survives transient buffer underruns.
 * 5. Clean thread join and flush before writing the 44-byte RIFF WAV header.
 */
class AudioRecorderManager(
    private val context: Context,
    private val onMaxDurationReached: () -> Unit
) {
    companion object {
        const val SAMPLE_RATE_HZ = 16_000
        const val MAX_DURATION_MS = 120_000
        private const val BYTES_PER_SAMPLE = 2 // 16-bit PCM
        private const val MAX_PCM_BYTES =
            (SAMPLE_RATE_HZ * BYTES_PER_SAMPLE * (MAX_DURATION_MS / 1000))
    }

    @Volatile
    private var isRecording = false

    private var audioRecord: AudioRecord? = null
    private var recordingThread: Thread? = null
    private var currentOutputFile: File? = null
    private var pcmBufferStream: ByteArrayOutputStream? = null

    @Volatile
    var lastPeakAmplitude: Int = 0
        private set

    @Synchronized
    fun startRecording(): Result<File> {
        stopAndReleaseInternal()
        val outputFile = File(
            context.cacheDir,
            "voicetype_rec_${System.currentTimeMillis()}.wav"
        )
        currentOutputFile = outputFile
        lastPeakAmplitude = 0

        return try {
            val minBufSize = AudioRecord.getMinBufferSize(
                SAMPLE_RATE_HZ,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val bufferSize = maxOf(minBufSize * 4, SAMPLE_RATE_HZ * 2)

            val record = createAudioRecord(bufferSize)
                ?: throw IllegalStateException("Microphone is unavailable or in use by another app.")

            val byteStream = ByteArrayOutputStream(SAMPLE_RATE_HZ * 4)
            pcmBufferStream = byteStream
            audioRecord = record

            record.startRecording()
            if (record.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                record.release()
                audioRecord = null
                throw IllegalStateException("Microphone failed to enter recording state.")
            }

            isRecording = true
            val thread = Thread({
                readAudioLoop(record, byteStream)
            }, "VoiceTypeAudioRecordThread")
            recordingThread = thread
            thread.start()

            Result.success(outputFile)
        } catch (e: Exception) {
            stopAndReleaseInternal()
            deleteFileSafely(outputFile)
            currentOutputFile = null
            Result.failure(e)
        }
    }

    @SuppressLint("MissingPermission")
    private fun createAudioRecord(bufferSize: Int): AudioRecord? {
        val sources = intArrayOf(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.DEFAULT,
            MediaRecorder.AudioSource.VOICE_COMMUNICATION
        )
        for (source in sources) {
            try {
                val ar = AudioRecord(
                    source,
                    SAMPLE_RATE_HZ,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
                if (ar.state == AudioRecord.STATE_INITIALIZED) {
                    return ar
                }
                ar.release()
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun readAudioLoop(record: AudioRecord, output: ByteArrayOutputStream) {
        val shortBuffer = ShortArray(512)
        val byteChunk = ByteArray(shortBuffer.size * 2)
        var consecutiveErrors = 0

        while (isRecording) {
            val readCount = try {
                record.read(shortBuffer, 0, shortBuffer.size)
            } catch (_: Exception) {
                -1
            }

            if (readCount > 0) {
                consecutiveErrors = 0
                var chunkPeak = 0
                for (i in 0 until readCount) {
                    val sample = shortBuffer[i].toInt()
                    val absVal = if (sample == Short.MIN_VALUE.toInt()) 32767 else abs(sample)
                    if (absVal > chunkPeak) {
                        chunkPeak = absVal
                    }
                    // Little-endian 16-bit PCM
                    byteChunk[i * 2] = (sample and 0xFF).toByte()
                    byteChunk[i * 2 + 1] = ((sample shr 8) and 0xFF).toByte()
                }
                if (chunkPeak > lastPeakAmplitude) {
                    lastPeakAmplitude = chunkPeak
                }

                synchronized(output) {
                    output.write(byteChunk, 0, readCount * 2)
                    if (output.size() >= MAX_PCM_BYTES) {
                        isRecording = false
                        onMaxDurationReached()
                    }
                }
            } else if (readCount == 0) {
                try {
                    Thread.sleep(10L)
                } catch (_: InterruptedException) {
                }
            } else {
                consecutiveErrors++
                if (consecutiveErrors > 15) {
                    break
                }
                try {
                    Thread.sleep(20L)
                } catch (_: InterruptedException) {
                }
            }
        }
    }

    /**
     * Stops recording, normalizes low-volume microphone audio so speech is crystal clear,
     * writes the complete RIFF WAV file to disk, and returns the `.wav` file.
     */
    @Synchronized
    fun stopRecording(): File? {
        val file = currentOutputFile
        val stream = pcmBufferStream
        if (!isRecording && (stream == null || stream.size() == 0)) {
            stopAndReleaseInternal()
            return null
        }

        isRecording = false

        // 1. Stop AudioRecord hardware capture first
        val record = audioRecord
        try {
            if (record != null && record.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                record.stop()
            }
        } catch (_: Exception) {
        }

        // 2. Wait for the reading thread to finish any active buffer iteration cleanly
        try {
            recordingThread?.join(600L)
        } catch (_: Exception) {
        }
        recordingThread = null

        // 3. Safely release native AudioRecord
        audioRecord = null
        try {
            record?.release()
        } catch (_: Exception) {
        }

        return try {
            val rawPcm = if (stream != null) {
                synchronized(stream) { stream.toByteArray() }
            } else {
                ByteArray(0)
            }
            pcmBufferStream = null

            // Require at least 0.05s of audio (800 samples = 1,600 bytes)
            if (file == null || rawPcm.size < (SAMPLE_RATE_HZ * BYTES_PER_SAMPLE / 20)) {
                deleteFileSafely(file)
                return null
            }

            val normalizedPcm = normalizePcm16Le(rawPcm)
            writeWavFile(file, normalizedPcm, SAMPLE_RATE_HZ)

            if (file.exists() && file.length() > 44L) {
                file
            } else {
                deleteFileSafely(file)
                null
            }
        } catch (e: Exception) {
            deleteFileSafely(file)
            null
        }
    }

    /**
     * Stops recording immediately and deletes any temporary audio file (used when ✕ is tapped).
     */
    @Synchronized
    fun cancelAndDeleteRecording() {
        val file = currentOutputFile
        isRecording = false

        val record = audioRecord
        try {
            if (record != null && record.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                record.stop()
            }
        } catch (_: Exception) {
        }

        try {
            recordingThread?.join(300L)
        } catch (_: Exception) {
        }
        recordingThread = null

        audioRecord = null
        try {
            record?.release()
        } catch (_: Exception) {
        }

        pcmBufferStream = null
        deleteFileSafely(file)
        currentOutputFile = null
    }

    private fun stopAndReleaseInternal() {
        isRecording = false
        val record = audioRecord
        audioRecord = null
        try {
            if (record != null && record.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                record.stop()
            }
        } catch (_: Exception) {
        }
        try {
            record?.release()
        } catch (_: Exception) {
        }
        pcmBufferStream = null
    }

    /**
     * Normalizes 16-bit little-endian PCM audio if the microphone gain is low,
     * ensuring Gemini receives a strong, clear speech signal without clipping.
     */
    fun normalizePcm16Le(pcmBytes: ByteArray): ByteArray {
        val sampleCount = pcmBytes.size / 2
        if (sampleCount == 0) return pcmBytes

        var peak = 0
        for (i in 0 until sampleCount) {
            val low = pcmBytes[i * 2].toInt() and 0xFF
            val high = pcmBytes[i * 2 + 1].toInt()
            val sample = ((high shl 8) or low).toShort().toInt()
            val absSample = abs(sample)
            if (absSample > peak) peak = absSample
        }

        // If peak is already strong (>= 22000) or completely zero, return as-is
        if (peak == 0 || peak >= 22_000) {
            return pcmBytes
        }

        // Compute safe gain multiplier (up to 30x) so quiet or distant speech reaches ~24,000 peak
        val targetPeak = 24_000.0
        val gain = (targetPeak / peak.toDouble()).coerceIn(1.0, 30.0)

        val out = ByteArray(pcmBytes.size)
        for (i in 0 until sampleCount) {
            val low = pcmBytes[i * 2].toInt() and 0xFF
            val high = pcmBytes[i * 2 + 1].toInt()
            val sample = ((high shl 8) or low).toShort().toInt()
            val boosted = (sample * gain).toInt().coerceIn(-32767, 32767)
            out[i * 2] = (boosted and 0xFF).toByte()
            out[i * 2 + 1] = ((boosted shr 8) and 0xFF).toByte()
        }
        return out
    }

    /**
     * Writes a standard 44-byte RIFF WAVE header followed by 16-bit mono PCM data.
     */
    fun writeWavFile(outputFile: File, pcmData: ByteArray, sampleRate: Int) {
        val totalDataLen = pcmData.size + 36
        val byteRate = sampleRate * BYTES_PER_SAMPLE

        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(totalDataLen)
            put("WAVE".toByteArray(Charsets.US_ASCII))
            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16) // Subchunk1Size for PCM
            putShort(1) // AudioFormat = 1 (PCM)
            putShort(1) // NumChannels = 1 (Mono)
            putInt(sampleRate)
            putInt(byteRate)
            putShort(BYTES_PER_SAMPLE.toShort()) // BlockAlign
            putShort(16) // BitsPerSample
            put("data".toByteArray(Charsets.US_ASCII))
            putInt(pcmData.size)
        }.array()

        FileOutputStream(outputFile).use { fos ->
            fos.write(header)
            fos.write(pcmData)
            fos.flush()
            try {
                fos.fd.sync()
            } catch (_: Exception) {
            }
        }
    }

    fun deleteFileSafely(file: File?) {
        try {
            if (file != null && file.exists()) {
                file.delete()
            }
        } catch (_: Exception) {
        }
    }
}
