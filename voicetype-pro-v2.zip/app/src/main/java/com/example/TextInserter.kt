package com.example

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo

data class UndoSnapshot(
    val previousText: String,
    val previousCursorIndex: Int,
    val insertedText: String,
    val timestampMs: Long
)

enum class InsertionOutcome {
    INSERTED_DIRECTLY,
    PASTED_VIA_CLIPBOARD,
    COPIED_ONLY_MANUAL_PASTE
}

/**
 * Handles cursor-aware text insertion into any focused editable AccessibilityNodeInfo,
 * clipboard fallback, and 30-second Undo restoration.
 */
object TextInserter {
    const val UNDO_WINDOW_MS = 30_000L

    @Volatile
    private var lastUndoSnapshot: UndoSnapshot? = null

    /**
     * Checks if there is an active Undo snapshot within the last 30 seconds.
     */
    fun canUndo(nowMs: Long = System.currentTimeMillis()): Boolean {
        val snapshot = lastUndoSnapshot ?: return false
        return (nowMs - snapshot.timestampMs) in 0..UNDO_WINDOW_MS
    }

    fun clearUndo() {
        lastUndoSnapshot = null
    }

    /**
     * Finds the focused editable node across the active window or interactive windows,
     * ignoring our own overlay window package.
     */
    fun findFocusedEditableNode(
        service: AccessibilityService,
        ownPackageName: String,
        cachedFocusedNode: AccessibilityNodeInfo?
    ): AccessibilityNodeInfo? {
        // 1. Try rootInActiveWindow.findFocus(FOCUS_INPUT)
        val root = try {
            service.rootInActiveWindow
        } catch (_: Exception) {
            null
        }

        if (root != null) {
            val focusedInput = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (focusedInput != null &&
                focusedInput.isEditable &&
                focusedInput.packageName?.toString() != ownPackageName
            ) {
                return focusedInput
            }
            val searchedInRoot = findEditableFocusedRecursive(root, ownPackageName)
            if (searchedInRoot != null) {
                return searchedInRoot
            }
        }

        // 2. Search all interactive windows (getWindows()) for an editable, focused node
        val windows = try {
            service.windows
        } catch (_: Exception) {
            null
        }
        if (windows != null) {
            for (window in windows) {
                val winRoot = window.root ?: continue
                if (winRoot.packageName?.toString() == ownPackageName) continue

                val focusInWindow = winRoot.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                if (focusInWindow != null &&
                    focusInWindow.isEditable &&
                    focusInWindow.packageName?.toString() != ownPackageName
                ) {
                    return focusInWindow
                }

                val recursiveMatch = findEditableFocusedRecursive(winRoot, ownPackageName)
                if (recursiveMatch != null) {
                    return recursiveMatch
                }
            }
            // Second pass: if an editable field exists in a non-overlay window even if focus flag flickered
            for (window in windows) {
                val winRoot = window.root ?: continue
                if (winRoot.packageName?.toString() == ownPackageName) continue
                val anyEditable = findFirstEditableRecursive(winRoot, ownPackageName)
                if (anyEditable != null) {
                    return anyEditable
                }
            }
        }

        // 3. Fallback to cached focused editable node from accessibility events
        if (cachedFocusedNode != null) {
            val refreshed = try {
                cachedFocusedNode.refresh()
                cachedFocusedNode
            } catch (_: Exception) {
                null
            }
            if (refreshed != null &&
                refreshed.isEditable &&
                refreshed.packageName?.toString() != ownPackageName
            ) {
                return refreshed
            }
        }

        return null
    }

    private fun findEditableFocusedRecursive(
        node: AccessibilityNodeInfo?,
        ownPackageName: String
    ): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.packageName?.toString() == ownPackageName) return null
        if (node.isEditable && (node.isFocused || node.isAccessibilityFocused)) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findEditableFocusedRecursive(child, ownPackageName)
            if (found != null) return found
        }
        return null
    }

    private fun findFirstEditableRecursive(
        node: AccessibilityNodeInfo?,
        ownPackageName: String
    ): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.packageName?.toString() == ownPackageName) return null
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findFirstEditableRecursive(child, ownPackageName)
            if (found != null) return found
        }
        return null
    }

    /**
     * Pure helper for computing the new text and cursor index when inserting [newText] at the
     * cursor/selection inside [existingText]. Adds a leading space if the character immediately
     * before the insertion point is not a whitespace or newline.
     */
    fun buildInsertedText(
        existingText: String,
        selectionStart: Int,
        selectionEnd: Int,
        newText: String
    ): Pair<String, Int> {
        val safeLen = existingText.length
        val start = if (selectionStart in 0..safeLen) selectionStart else safeLen
        val end = if (selectionEnd in 0..safeLen) selectionEnd else start
        val minIdx = minOf(start, end)
        val maxIdx = maxOf(start, end)

        val before = existingText.substring(0, minIdx)
        val after = existingText.substring(maxIdx, safeLen)

        val needsLeadingSpace = before.isNotEmpty() &&
            !before.last().isWhitespace() &&
            newText.isNotEmpty() &&
            !newText.first().isWhitespace()

        val textToInsert = if (needsLeadingSpace) " $newText" else newText
        val combined = before + textToInsert + after
        val newCursorIndex = before.length + textToInsert.length
        return combined to newCursorIndex
    }

    /**
     * Inserts [transcribedText] directly into the focused input field with ACTION_SET_TEXT
     * (cursor-aware, no clipboard involved).
     *
     * Only when ACTION_SET_TEXT fails AND [allowFallbacks] is true does it fall back to
     * clipboard + ACTION_PASTE, and finally to "copied, paste manually".
     * Callers that retry should pass allowFallbacks = false on every attempt except the last,
     * so the clipboard is never touched when a later attempt would succeed directly.
     */
    fun insertText(
        context: Context,
        service: AccessibilityService?,
        cachedFocusedNode: AccessibilityNodeInfo?,
        transcribedText: String,
        allowFallbacks: Boolean = true
    ): InsertionOutcome {
        val cleanText = transcribedText.trim()
        if (cleanText.isEmpty()) return InsertionOutcome.INSERTED_DIRECTLY

        // Candidate targets: the live FOCUS_INPUT node first, then the cached node from events.
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        if (service != null) {
            findFocusedEditableNode(service, context.packageName, cachedFocusedNode)?.let { candidates.add(it) }
        }
        if (cachedFocusedNode != null && candidates.none { it == cachedFocusedNode }) {
            val usable = try {
                cachedFocusedNode.refresh() && cachedFocusedNode.isEditable &&
                    cachedFocusedNode.packageName?.toString() != context.packageName
            } catch (_: Exception) {
                false
            }
            if (usable) candidates.add(cachedFocusedNode)
        }

        // Pass 1: ACTION_SET_TEXT on each candidate
        for (node in candidates) {
            val result = trySetText(node, cleanText)
            if (result) return InsertionOutcome.INSERTED_DIRECTLY
        }

        if (!allowFallbacks) return InsertionOutcome.COPIED_ONLY_MANUAL_PASTE

        // Pass 2 (only after SET_TEXT failed): clipboard + ACTION_PASTE
        copyToClipboard(context, cleanText)
        for (node in candidates) {
            val currentText = readCurrentText(node)
            val prevCursor = node.textSelectionStart.takeIf { it >= 0 } ?: currentText.length
            if (node.performAction(AccessibilityNodeInfo.ACTION_PASTE)) {
                lastUndoSnapshot = UndoSnapshot(
                    previousText = currentText,
                    previousCursorIndex = prevCursor.coerceIn(0, currentText.length),
                    insertedText = cleanText,
                    timestampMs = System.currentTimeMillis()
                )
                return InsertionOutcome.PASTED_VIA_CLIPBOARD
            }
        }

        // Pass 3: text stays on the clipboard for a manual paste
        return InsertionOutcome.COPIED_ONLY_MANUAL_PASTE
    }

    private fun readCurrentText(node: AccessibilityNodeInfo): String {
        val isHint = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) node.isShowingHintText else false
        return if (isHint) "" else (node.text?.toString() ?: "")
    }

    /**
     * Refreshes [node], builds the new text around the cursor and applies ACTION_SET_TEXT.
     * Returns true on success and records the 30-second undo snapshot.
     */
    private fun trySetText(node: AccessibilityNodeInfo, cleanText: String): Boolean {
        try {
            node.refresh()
        } catch (_: Exception) {
        }
        val isHint = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) node.isShowingHintText else false
        val currentText = readCurrentText(node)
        val selStart = if (isHint) 0 else node.textSelectionStart
        val selEnd = if (isHint) 0 else node.textSelectionEnd

        val (updatedText, newCursorPos) = buildInsertedText(
            existingText = currentText,
            selectionStart = selStart,
            selectionEnd = selEnd,
            newText = cleanText
        )

        val setArgs = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, updatedText)
        }
        if (!node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, setArgs)) return false

        // Move cursor to the end of the inserted text
        val selectionArgs = Bundle().apply {
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, newCursorPos)
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, newCursorPos)
        }
        node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selectionArgs)

        val prevCursor = (if (selStart >= 0) selStart else currentText.length).coerceIn(0, currentText.length)
        lastUndoSnapshot = UndoSnapshot(
            previousText = currentText,
            previousCursorIndex = prevCursor,
            insertedText = updatedText.substring(minOf(prevCursor, newCursorPos), newCursorPos),
            timestampMs = System.currentTimeMillis()
        )
        return true
    }

    /**
     * Restores the field's previous text if the last insertion occurred less than 30 seconds ago.
     */
    fun undoLastInsertion(
        context: Context,
        service: AccessibilityService?,
        cachedFocusedNode: AccessibilityNodeInfo?
    ): Boolean {
        val snapshot = lastUndoSnapshot ?: return false
        if (!canUndo()) {
            lastUndoSnapshot = null
            return false
        }
        val activeService = service ?: return false
        val node = findFocusedEditableNode(activeService, context.packageName, cachedFocusedNode)
            ?: return false

        val setArgs = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                snapshot.previousText
            )
        }
        val restored = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, setArgs)
        if (restored) {
            val cursor = snapshot.previousCursorIndex.coerceIn(0, snapshot.previousText.length)
            val selArgs = Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, cursor)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, cursor)
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selArgs)
            lastUndoSnapshot = null
            return true
        }
        return false
    }

    fun copyToClipboard(context: Context, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        val clip = ClipData.newPlainText("VoiceType Pro Transcription", text)
        clipboard?.setPrimaryClip(clip)
    }
}
