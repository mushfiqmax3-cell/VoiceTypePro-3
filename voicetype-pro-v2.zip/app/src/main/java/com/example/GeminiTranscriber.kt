package com.example

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class TranscriptionResponse(
    val text: String,
    val modelUsed: String,
    val usedFallbackModel: Boolean
)

sealed class TranscriptionException(message: String) : Exception(message) {
    class NoInternet : TranscriptionException("No internet connection. Please check your network.")
    class InvalidApiKey : TranscriptionException("Invalid Gemini API key. Check your key in VoiceType Pro.")
    class QuotaExceeded : TranscriptionException("Quota exceeded (429). Please wait a moment and try again.")
    class EmptyResult : TranscriptionException("No speech detected (কোনো কথা শনাক্ত হয়নি).")
    class ModelNotFound(model: String) : TranscriptionException("Model '$model' not available (404). Change the model in VoiceType Pro settings.")
    class ApiError(msg: String) : TranscriptionException(msg)
}

/**
 * Handles inline base64 audio transcription with the Gemini API over OkHttp + Coroutines.
 * Uses official Google Generative Language REST API camelCase keys ("inlineData", "mimeType")
 * and defaults to "gemini-3.8-flash".
 */
object GeminiTranscriber {
    const val TRANSCRIPTION_PROMPT =
        "You are an expert bilingual speech-to-text engine for Bengali (বাংলা) and English. " +
        "Transcribe everything spoken in this audio with high fidelity. " +
        "Rules:\n" +
        "1. Write Bengali words in Bengali script (বাংলা হরফ) and English words in Latin alphabet (English).\n" +
        "2. Accurately transcribe mixed Bengali and English (Banglish) code-switching.\n" +
        "3. Even if the voice is soft, quiet, fast, or recorded through an emulator microphone, capture every audible spoken word verbatim.\n" +
        "4. Add natural sentence punctuation (যেমন: ।, ?, !, .).\n" +
        "5. Return ONLY the transcribed text. Do NOT add quotes, markdown formatting, explanations, apologies, or conversational filler."

    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    @Volatile
    private var activeCall: Call? = null

    /**
     * Cancels any in-flight OkHttp network request immediately.
     */
    fun cancelActiveRequest() {
        try {
            activeCall?.cancel()
        } catch (_: Exception) {
        } finally {
            activeCall = null
        }
    }

    /**
     * Reads the closed and flushed audio file safely into a byte array.
     */
    private fun readClosedAudioBytes(audioFile: File): ByteArray {
        FileInputStream(audioFile).use { fis ->
            return fis.readBytes()
        }
    }

    /**
     * Detects the MIME type from the audio file header or extension ("audio/wav" or "audio/mp4").
     */
    fun detectAudioMimeType(audioFile: File, bytes: ByteArray): String {
        if (bytes.size >= 12 &&
            bytes[0] == 'R'.code.toByte() &&
            bytes[1] == 'I'.code.toByte() &&
            bytes[2] == 'F'.code.toByte() &&
            bytes[3] == 'F'.code.toByte()
        ) {
            return "audio/wav"
        }
        return if (audioFile.extension.equals("wav", ignoreCase = true)) {
            "audio/wav"
        } else {
            "audio/mp4"
        }
    }

    /**
     * Sends the recorded audio file inline (Base64) to Gemini and returns the trimmed transcription.
     * Always deletes [audioFile] in the finally block (success, failure, or cancellation).
     */
    suspend fun transcribeAudio(
        audioFile: File,
        apiKey: String,
        configuredModel: String = Prefs.DEFAULT_MODEL_NAME,
        appPackage: String? = null
    ): Result<TranscriptionResponse> = withContext(Dispatchers.IO) {
        try {
            val cleanKey = apiKey.trim()
            if (cleanKey.isEmpty()) {
                return@withContext Result.failure(TranscriptionException.InvalidApiKey())
            }
            if (!audioFile.exists() || audioFile.length() <= 44L) {
                return@withContext Result.failure(TranscriptionException.EmptyResult())
            }

            val audioBytes = readClosedAudioBytes(audioFile)
            if (audioBytes.size <= 44) {
                return@withContext Result.failure(TranscriptionException.EmptyResult())
            }

            val mimeType = detectAudioMimeType(audioFile, audioBytes)
            val base64Audio = Base64.encodeToString(audioBytes, Base64.NO_WRAP)
            val requestBodyJson = buildTranscriptionJson(
                base64Audio,
                mimeType,
                buildPrompt(appPackage)
            )

            val primaryModel = configuredModel.trim().ifEmpty { Prefs.DEFAULT_MODEL_NAME }
            val primaryAttempt = executeGenerateContent(
                model = primaryModel,
                apiKey = cleanKey,
                bodyJson = requestBodyJson
            )

            if (primaryAttempt.isModelNotFound && primaryModel != Prefs.FALLBACK_MODEL_NAME) {
                val fallbackAttempt = executeGenerateContent(
                    model = Prefs.FALLBACK_MODEL_NAME,
                    apiKey = cleanKey,
                    bodyJson = requestBodyJson
                )
                if (fallbackAttempt.isModelNotFound) {
                    return@withContext Result.failure(TranscriptionException.ModelNotFound(Prefs.FALLBACK_MODEL_NAME))
                }
                if (fallbackAttempt.exception != null) {
                    return@withContext Result.failure(fallbackAttempt.exception)
                }
                val text = cleanExtractedTranscript(fallbackAttempt.extractedText.orEmpty())
                if (text.isEmpty()) {
                    return@withContext Result.failure(TranscriptionException.EmptyResult())
                }
                return@withContext Result.success(
                    TranscriptionResponse(
                        text = text,
                        modelUsed = Prefs.FALLBACK_MODEL_NAME,
                        usedFallbackModel = true
                    )
                )
            }

            if (primaryAttempt.exception != null) {
                return@withContext Result.failure(primaryAttempt.exception)
            }

            val text = cleanExtractedTranscript(primaryAttempt.extractedText.orEmpty())
            if (text.isEmpty()) {
                return@withContext Result.failure(TranscriptionException.EmptyResult())
            }

            Result.success(
                TranscriptionResponse(
                    text = text,
                    modelUsed = primaryModel,
                    usedFallbackModel = false
                )
            )
        } catch (e: kotlinx.coroutines.CancellationException) {
            cancelActiveRequest()
            throw e
        } catch (e: UnknownHostException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: SocketTimeoutException) {
            Result.failure(TranscriptionException.ApiError("Connection timed out. Please try again."))
        } catch (e: IOException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: Exception) {
            Result.failure(TranscriptionException.ApiError(e.localizedMessage ?: "Transcription failed."))
        } finally {
            activeCall = null
            try {
                if (audioFile.exists()) {
                    audioFile.delete()
                }
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Makes a tiny test request to validate the user's API key and model configuration.
     */
    suspend fun testApiKey(
        apiKey: String,
        configuredModel: String = Prefs.DEFAULT_MODEL_NAME
    ): Result<TranscriptionResponse> = withContext(Dispatchers.IO) {
        try {
            val cleanKey = apiKey.trim()
            if (cleanKey.isEmpty()) {
                return@withContext Result.failure(TranscriptionException.InvalidApiKey())
            }

            val testJson = JSONObject().apply {
                val part = JSONObject().put("text", "Reply with OK")
                val parts = JSONArray().put(part)
                val content = JSONObject().put("parts", parts)
                put("contents", JSONArray().put(content))
                put("generationConfig", JSONObject().put("temperature", 0))
            }.toString()

            val primaryModel = configuredModel.trim().ifEmpty { Prefs.DEFAULT_MODEL_NAME }
            val primaryAttempt = executeGenerateContent(
                model = primaryModel,
                apiKey = cleanKey,
                bodyJson = testJson
            )

            if (primaryAttempt.isModelNotFound && primaryModel != Prefs.FALLBACK_MODEL_NAME) {
                val fallbackAttempt = executeGenerateContent(
                    model = Prefs.FALLBACK_MODEL_NAME,
                    apiKey = cleanKey,
                    bodyJson = testJson
                )
                if (fallbackAttempt.exception != null) {
                    return@withContext Result.failure(fallbackAttempt.exception)
                }
                return@withContext Result.success(
                    TranscriptionResponse(
                        text = fallbackAttempt.extractedText.orEmpty().trim().ifEmpty { "OK" },
                        modelUsed = Prefs.FALLBACK_MODEL_NAME,
                        usedFallbackModel = true
                    )
                )
            }

            if (primaryAttempt.exception != null) {
                return@withContext Result.failure(primaryAttempt.exception)
            }

            Result.success(
                TranscriptionResponse(
                    text = primaryAttempt.extractedText.orEmpty().trim().ifEmpty { "OK" },
                    modelUsed = primaryModel,
                    usedFallbackModel = false
                )
            )
        } catch (e: UnknownHostException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: SocketTimeoutException) {
            Result.failure(TranscriptionException.ApiError("Request timed out."))
        } catch (e: IOException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: Exception) {
            Result.failure(TranscriptionException.ApiError(e.localizedMessage ?: "Validation failed."))
        }
    }

    /**
     * Builds the official Google Generative Language REST API JSON payload using camelCase keys:
     * parts: [ { "inlineData": { "mimeType": mimeType, "data": base64Audio } }, { "text": TRANSCRIPTION_PROMPT } ]
     */
    fun buildTranscriptionJson(
        base64Audio: String,
        mimeType: String = "audio/wav",
        prompt: String = TRANSCRIPTION_PROMPT
    ): String {
        val inlineData = JSONObject().apply {
            put("mimeType", mimeType)
            put("data", base64Audio)
        }
        val audioPart = JSONObject().apply {
            put("inlineData", inlineData)
        }
        val textPart = JSONObject().apply {
            put("text", prompt)
        }
        val partsArray = JSONArray().apply {
            put(audioPart)
            put(textPart)
        }
        val contentObj = JSONObject().apply {
            put("role", "user")
            put("parts", partsArray)
        }
        val contentsArray = JSONArray().apply {
            put(contentObj)
        }
        val generationConfig = JSONObject().apply {
            put("temperature", 0)
        }
        return JSONObject().apply {
            put("contents", contentsArray)
            put("generationConfig", generationConfig)
        }.toString()
    }

    // ---------------------------------------------------------------------------------------
    // App-aware tone
    // ---------------------------------------------------------------------------------------

    private val FORMAL_EMAIL_APPS = setOf(
        "com.google.android.gm",
        "com.microsoft.office.outlook",
        "com.yahoo.mobile.client.android.mail",
        "ch.protonmail.android",
        "com.samsung.android.email.provider"
    )
    private val CASUAL_CHAT_APPS = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "org.telegram.messenger",
        "org.thoughtcrime.securesms",
        "com.facebook.orca",
        "com.facebook.katana",
        "com.instagram.android",
        "com.discord",
        "com.snapchat.android",
        "com.google.android.apps.messaging",
        "com.samsung.android.messaging",
        "com.viber.voip",
        "jp.naver.line.android"
    )
    private val WORK_CHAT_APPS = setOf(
        "com.slack",
        "com.microsoft.teams",
        "com.google.android.apps.dynamite"
    )
    private val DOCUMENT_APPS = setOf(
        "com.google.android.keep",
        "com.google.android.apps.docs.editors.docs",
        "com.microsoft.office.word",
        "com.microsoft.office.onenote",
        "notion.id",
        "md.obsidian"
    )

    /**
     * Returns a one-line tone instruction for the app the user is typing into,
     * or null when no special tone applies.
     */
    fun toneInstructionFor(appPackage: String?): String? {
        val pkg = appPackage?.trim().orEmpty()
        return when {
            pkg.isEmpty() -> null
            pkg in FORMAL_EMAIL_APPS ->
                "The text is for an EMAIL. Use a polite, formal, professional tone with complete sentences and proper punctuation."
            pkg in WORK_CHAT_APPS ->
                "The text is for a WORK CHAT message. Use a clear, professional but conversational tone."
            pkg in CASUAL_CHAT_APPS ->
                "The text is for a casual CHAT message. Use a relaxed, natural, conversational tone; short sentences are fine."
            pkg in DOCUMENT_APPS ->
                "The text is for a NOTE or DOCUMENT. Use clear, well-structured written language."
            else -> null
        }
    }

    /**
     * Base transcription prompt plus an optional tone line derived from [appPackage].
     */
    fun buildPrompt(appPackage: String?): String {
        val tone = toneInstructionFor(appPackage) ?: return TRANSCRIPTION_PROMPT
        return TRANSCRIPTION_PROMPT +
            "\n6. Context: $tone Adjust only punctuation, capitalization and formality of wording to suit it. " +
            "Keep the original meaning and the original language of each word; never add, remove, or translate content."
    }

    // ---------------------------------------------------------------------------------------
    // Model list (Settings dropdown)
    // ---------------------------------------------------------------------------------------

    private val EXCLUDED_MODEL_KEYWORDS = listOf(
        "tts", "image", "embedding", "live", "native-audio", "robotics", "computer-use", "aqa", "imagen", "veo"
    )

    /**
     * Parses a `models.list` response and returns the Gemini model IDs (without the `models/` prefix)
     * that support `generateContent`, excluding TTS / image / live / embedding variants.
     */
    fun parseModelsJson(json: String): List<String> {
        val root = JSONObject(json)
        val models = root.optJSONArray("models") ?: return emptyList()
        val result = LinkedHashSet<String>()
        for (i in 0 until models.length()) {
            val m = models.optJSONObject(i) ?: continue
            val id = m.optString("name", "").removePrefix("models/")
            if (!id.startsWith("gemini")) continue
            if (EXCLUDED_MODEL_KEYWORDS.any { id.contains(it) }) continue
            val methods = m.optJSONArray("supportedGenerationMethods")
            var supportsGenerate = methods == null
            if (methods != null) {
                for (j in 0 until methods.length()) {
                    if (methods.optString(j) == "generateContent") supportsGenerate = true
                }
            }
            if (supportsGenerate) result.add(id)
        }
        return result.toList().sortedDescending()
    }

    /**
     * GET https://generativelanguage.googleapis.com/v1beta/models and returns the usable model IDs.
     * The key is sent in the `x-goog-api-key` header (same effect as `?key=`, but stays out of URLs and logs).
     */
    suspend fun fetchAvailableModels(apiKey: String): Result<List<String>> = withContext(Dispatchers.IO) {
        try {
            val cleanKey = apiKey.trim()
            if (cleanKey.isEmpty()) {
                return@withContext Result.failure(TranscriptionException.InvalidApiKey())
            }
            val all = LinkedHashSet<String>()
            var pageToken: String? = null
            var pages = 0
            do {
                val urlBuilder = "https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000" +
                    (pageToken?.let { "&pageToken=$it" } ?: "")
                val request = Request.Builder()
                    .url(urlBuilder)
                    .addHeader("x-goog-api-key", cleanKey)
                    .get()
                    .build()
                val call = okHttpClient.newCall(request)
                val (code, body) = suspendCancellableCoroutine<Pair<Int, String>> { cont ->
                    cont.invokeOnCancellation { call.cancel() }
                    call.enqueue(object : Callback {
                        override fun onFailure(call: Call, e: IOException) {
                            if (!cont.isCancelled) cont.resumeWithException(e)
                        }

                        override fun onResponse(call: Call, response: Response) {
                            response.use { r ->
                                val s = r.body?.string().orEmpty()
                                if (!cont.isCancelled) cont.resume(r.code to s)
                            }
                        }
                    })
                }
                if (code == 400 || code == 401 || code == 403) {
                    return@withContext Result.failure(TranscriptionException.InvalidApiKey())
                }
                if (code == 429) {
                    return@withContext Result.failure(TranscriptionException.QuotaExceeded())
                }
                if (code !in 200..299) {
                    return@withContext Result.failure(
                        TranscriptionException.ApiError(parseErrorMessage(body) ?: "Server error ($code).")
                    )
                }
                all.addAll(parseModelsJson(body))
                pageToken = JSONObject(body).optString("nextPageToken", "").ifEmpty { null }
                pages++
            } while (pageToken != null && pages < 5)

            Result.success(all.toList().sortedDescending())
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: UnknownHostException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: IOException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: Exception) {
            Result.failure(TranscriptionException.ApiError(e.localizedMessage ?: "Could not load models."))
        }
    }

    private fun cleanExtractedTranscript(raw: String): String {
        var text = raw.trim()
        if (text.startsWith("```") && text.endsWith("```")) {
            text = text.removeSurrounding("```").trim()
            if (text.startsWith("text\n") || text.startsWith("json\n")) {
                text = text.substringAfter('\n').trim()
            }
        }
        text = text.removeSurrounding("\"").removeSurrounding("'").trim()
        val lower = text.lowercase()
        if (lower == "no speech" ||
            lower == "no speech detected" ||
            lower == "no speech detected." ||
            lower == "[silence]" ||
            lower == "(silence)" ||
            lower == "silence" ||
            lower == "nothing" ||
            lower == "none"
        ) {
            return ""
        }
        return text
    }

    private data class RawApiAttempt(
        val extractedText: String? = null,
        val isModelNotFound: Boolean = false,
        val exception: TranscriptionException? = null
    )

    private suspend fun executeGenerateContent(
        model: String,
        apiKey: String,
        bodyJson: String
    ): RawApiAttempt {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        val request = Request.Builder()
            .url(url)
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(bodyJson.toRequestBody(JSON_MEDIA_TYPE))
            .build()

        val call = okHttpClient.newCall(request)
        activeCall = call

        val (code, responseBody) = suspendCancellableCoroutine<Pair<Int, String>> { cont ->
            cont.invokeOnCancellation {
                try {
                    call.cancel()
                } catch (_: Exception) {
                }
            }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    if (!cont.isCancelled) {
                        cont.resumeWithException(e)
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use { resp ->
                        val bodyStr = resp.body?.string().orEmpty()
                        if (!cont.isCancelled) {
                            cont.resume(resp.code to bodyStr)
                        }
                    }
                }
            })
        }

        if (code == 404) {
            return RawApiAttempt(isModelNotFound = true)
        }

        if (code == 400 || code == 401 || code == 403) {
            val lower = responseBody.lowercase()
            if (lower.contains("api_key_invalid") ||
                lower.contains("api key not valid") ||
                lower.contains("invalid api key") ||
                code == 401 || code == 403
            ) {
                return RawApiAttempt(exception = TranscriptionException.InvalidApiKey())
            }
            if (lower.contains("not found") || lower.contains("is not found for api version")) {
                return RawApiAttempt(isModelNotFound = true)
            }
            return RawApiAttempt(
                exception = TranscriptionException.ApiError(
                    parseErrorMessage(responseBody) ?: "Request error ($code)."
                )
            )
        }

        if (code == 429) {
            return RawApiAttempt(exception = TranscriptionException.QuotaExceeded())
        }

        if (code !in 200..299) {
            return RawApiAttempt(
                exception = TranscriptionException.ApiError(
                    parseErrorMessage(responseBody) ?: "Server error ($code)."
                )
            )
        }

        val extracted = extractCandidatesText(responseBody)
        return RawApiAttempt(extractedText = extracted)
    }

    fun extractCandidatesText(jsonString: String): String {
        return try {
            val root = JSONObject(jsonString)
            val candidates = root.optJSONArray("candidates") ?: return ""
            if (candidates.length() == 0) return ""
            val firstCandidate = candidates.optJSONObject(0) ?: return ""
            val content = firstCandidate.optJSONObject("content") ?: return ""
            val parts = content.optJSONArray("parts") ?: return ""
            val builder = StringBuilder()
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i) ?: continue
                if (part.optBoolean("thought", false)) continue
                val text = part.optString("text", "")
                if (text.isNotEmpty()) {
                    builder.append(text)
                }
            }
            builder.toString().trim()
        } catch (_: Exception) {
            ""
        }
    }

    private fun parseErrorMessage(jsonString: String): String? {
        return try {
            val root = JSONObject(jsonString)
            val err = root.optJSONObject("error") ?: return null
            err.optString("message", "").takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }
}
