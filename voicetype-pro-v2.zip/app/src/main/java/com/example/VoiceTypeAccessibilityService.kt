package com.example

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.text.TextUtils
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * AccessibilityService that tracks the currently focused editable text field in any external app
 * and enables VoiceType Pro to insert transcribed Bengali + English text at the active cursor.
 */
class VoiceTypeAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: VoiceTypeAccessibilityService? = null
            private set

        @Volatile
        var lastFocusedEditableNode: AccessibilityNodeInfo? = null
            private set

        private val _textFieldFocused = MutableStateFlow(false)

        /** True while an editable text field (in any other app) has input focus. */
        val textFieldFocused: StateFlow<Boolean> = _textFieldFocused.asStateFlow()

        @Volatile
        private var lastAppPackage: String? = null

        /**
         * Package name of the app the user is currently typing into (e.g. com.google.android.gm),
         * or null if unknown. Our own package and keyboard (IME) packages are never returned.
         */
        fun currentAppPackage(context: Context): String? {
            val svc = instance
            val fromNode = try {
                lastFocusedEditableNode?.packageName?.toString()
            } catch (_: Exception) {
                null
            }
            val fromRoot = try {
                svc?.rootInActiveWindow?.packageName?.toString()
            } catch (_: Exception) {
                null
            }
            return listOf(fromRoot, fromNode, lastAppPackage)
                .firstOrNull { !it.isNullOrBlank() && it != context.packageName && !isImePackage(context, it) }
        }

        private fun isImePackage(context: Context, pkg: String): Boolean {
            return try {
                val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                imm?.enabledInputMethodList?.any { it.packageName == pkg } == true
            } catch (_: Exception) {
                false
            }
        }

        /**
         * Inserts transcribed text into the focused input field with ACTION_SET_TEXT.
         * Clipboard ACTION_PASTE is used only if SET_TEXT fails and [allowFallbacks] is true.
         */
        fun insertTranscribedText(
            context: Context,
            text: String,
            allowFallbacks: Boolean = true
        ): InsertionOutcome {
            return TextInserter.insertText(
                context = context,
                service = instance,
                cachedFocusedNode = lastFocusedEditableNode,
                transcribedText = text,
                allowFallbacks = allowFallbacks
            )
        }

        /**
         * Retries direct insertion a few times (the target window can be briefly unavailable right
         * after the network call returns) and only uses clipboard fallbacks on the final attempt.
         */
        suspend fun insertTranscribedTextWithRetry(context: Context, text: String): InsertionOutcome {
            val attempts = 3
            var outcome = InsertionOutcome.COPIED_ONLY_MANUAL_PASTE
            for (i in 1..attempts) {
                val last = i == attempts
                outcome = insertTranscribedText(context, text, allowFallbacks = last)
                if (outcome == InsertionOutcome.INSERTED_DIRECTLY ||
                    outcome == InsertionOutcome.PASTED_VIA_CLIPBOARD
                ) {
                    return outcome
                }
                if (!last) delay(150L)
            }
            return outcome
        }

        /**
         * Undoes the last inserted transcription if performed within 30 seconds.
         */
        fun performUndoIfAvailable(context: Context): Boolean {
            return TextInserter.undoLastInsertion(
                context = context,
                service = instance,
                cachedFocusedNode = lastFocusedEditableNode
            )
        }

        /**
         * Checks whether VoiceTypeAccessibilityService is enabled in system Accessibility settings.
         */
        fun isServiceEnabled(context: Context): Boolean {
            if (instance != null) return true
            val expectedComponent = ComponentName(context, VoiceTypeAccessibilityService::class.java)
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            val splitter = TextUtils.SimpleStringSplitter(':')
            splitter.setString(enabledServices)
            while (splitter.hasNext()) {
                val componentNameString = splitter.next()
                val enabledComponent = ComponentName.unflattenFromString(componentNameString)
                if (enabledComponent != null && enabledComponent == expectedComponent) {
                    return true
                }
            }
            return false
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString()
        // Ignore events originating from our own overlay window
        if (pkg == packageName) return
        // Ignore keyboard (IME) windows so they never replace the target app
        if (pkg != null && isImePackage(this, pkg)) return

        if (pkg != null) lastAppPackage = pkg

        val source = event.source
        if (source != null && source.isEditable) {
            lastFocusedEditableNode = source
            _textFieldFocused.value = true
            return
        }

        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_FOCUSED -> {
                // Focus moved to a non-editable view (button, list, ...) -> no text field focused
                val focused = findFocusedEditable()
                _textFieldFocused.value = focused != null
                if (focused != null) lastFocusedEditableNode = focused
            }

            AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                val focused = findFocusedEditable()
                _textFieldFocused.value = focused != null
                if (focused != null) lastFocusedEditableNode = focused
            }
        }
    }

    private fun findFocusedEditable(): AccessibilityNodeInfo? {
        val root = try {
            rootInActiveWindow
        } catch (_: Exception) {
            null
        } ?: return null
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        return if (focused != null &&
            focused.isEditable &&
            focused.packageName?.toString() != packageName
        ) {
            focused
        } else {
            null
        }
    }

    override fun onInterrupt() {
        // Required override for AccessibilityService
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        lastFocusedEditableNode = null
        _textFieldFocused.value = false
        super.onDestroy()
    }
}
